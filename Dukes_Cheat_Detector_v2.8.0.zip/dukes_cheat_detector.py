
import os, json, tempfile, subprocess, threading, hashlib, secrets, getpass, urllib.request, urllib.error
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

APP_NAME = "Dukes Cheat Detector"
VERSION = "2.8.0"

# Stricter known-family terms (prefer distinctive names / common executable stems).
# Matching is still heuristic name-based; modern memory-only or heavily renamed cheats can evade.
KNOWN = {
    "Solara": ["solara", "solara.exe", "solara_"],
    "Xeno": ["xeno", "xeno.exe", "xeno_"],
    "JJSploit": ["jjsploit", "jjsploit.exe"],
    "Velocity": ["velocity", "velocity.exe"],
    "Comet": ["comet", "comet.exe"],
    "Delta": ["delta", "delta.exe", "deltaexecutor"],
    "Volt": ["volt", "volt.exe", "volt_"],
    "Wave": ["wave", "wave.exe", "waveexecutor"],
    "Synapse Z": ["synapse z", "synapsez", "synapse-z", "synapsez.exe"],
    "Fluxus": ["fluxus", "fluxus.exe"],
    "Krnl": ["krnl", "krnl.exe", "krnl_"],
    "Hydrogen": ["hydrogen", "hydrogen.exe"],
    "Codex": ["codex", "codex.exe"],
    "Arceus X": ["arceus x", "arceusx", "arceusx.exe"],
    "SirHurt": ["sirhurt", "sirhurt.exe"],
    "Severe": ["severe", "severe.exe"],
    "Potassium": ["potassium", "potassium.exe"],
    "Matcha": ["matcha", "matcha.exe"],
    "Serotonin": ["serotonin", "serotonin.exe"],
    "Electron": ["electron", "electron.exe"],  # common name; score tempered below
}
GENERIC = ["executor", "inject", "injector", "scriptware", "wearedevs", "rbxscript"]
EXTS = {".exe", ".dll", ".sys", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".scr", ".msi"}
EXCLUDES = (
    "\\windows\\winxs", "\\windows\\servicing",
    "\\windows\\system32\\driverstore", "\\windows\\softwaredistribution",
    "\\program files\\windowsapps",
    "\\programdata\\microsoft\\windows defender",
    "\\program files\\microsoft", "\\program files (x86)\\microsoft",
    "\\program files\\google", "\\program files (x86)\\google",
    "\\program files\\mozilla", "\\program files (x86)\\mozilla",
    "\\node_modules", "\\steam\\steamapps",
)
# Paths / names that commonly cause false positives and should be ignored
FALSE_POSITIVE_HINTS = (
    "electron",  # many legitimate apps (Discord, VS Code, Slack, etc.) use Electron
    "microsoft edge", "chrome", "firefox", "discord", "steam", "epic games",
    "nvidia", "amd", "intel", "realtek", "windows defender", "onedrive",
)
def norm(x): return str(x).lower().replace("/","\\")


CONFIG_DIR = Path(os.environ.get("APPDATA", str(Path.home()))) / "CheatDetectorPro"
CONFIG_FILE = CONFIG_DIR / "owner.json"
LOG_FILE = CONFIG_DIR / "audit_log.jsonl"


WEBHOOK_CONFIG = CONFIG_DIR / "webhook.json"
REMOTE_CONFIG = CONFIG_DIR / "remote.json"
DEFAULT_REMOTE_URL = "https://cheat-detector-server.onrender.com"

def load_remote_config():
    try:
        if REMOTE_CONFIG.exists():
            cfg = json.loads(REMOTE_CONFIG.read_text(encoding="utf-8"))
            cfg.setdefault("server_url", DEFAULT_REMOTE_URL)
            cfg.setdefault("device_id", secrets.token_hex(16))
            cfg.setdefault("device_token", "")
            # Consent must be explicitly granted; never assume True
            cfg.setdefault("consent", False)
            cfg.setdefault("local_scan_consent", False)
            return cfg
    except Exception:
        pass
    return {
        "server_url": DEFAULT_REMOTE_URL,
        "device_id": secrets.token_hex(16),
        "device_token": "",
        "consent": False,
        "local_scan_consent": False,
    }
def save_remote_config(cfg):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    REMOTE_CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

def register_remote_device(cfg):
    payload={"device_id":cfg.get("device_id",""),"app_version":VERSION}
    url=cfg.get("server_url",DEFAULT_REMOTE_URL).rstrip("/")+"/api/v1/register"
    req=urllib.request.Request(url,data=json.dumps(payload).encode("utf-8"),headers={"Content-Type":"application/json","Accept":"application/json"},method="POST")
    with urllib.request.urlopen(req,timeout=15) as r:
        data=json.loads(r.read().decode("utf-8"))
    token=data.get("device_token","")
    if not token: raise RuntimeError("Server did not return a device token")
    cfg["device_id"]=data.get("device_id",cfg.get("device_id"))
    cfg["device_token"]=token
    save_remote_config(cfg)
    return True

def send_remote_event(event_type, detections=None):
    cfg=load_remote_config()
    if not cfg.get("consent"):
        return False, "Remote reporting consent is not enabled."
    try:
        if not cfg.get("device_token"):
            register_remote_device(cfg)
    except Exception as e:
        return False, "Registration failed: "+str(e)
    ident=current_identity()
    payload={"device_id":cfg.get("device_id",""),"windows_user":ident["windows_user"],"computer":ident["computer"],"event_type":event_type,"detections":detections or [],"app_version":VERSION}
    url=cfg.get("server_url",DEFAULT_REMOTE_URL).rstrip("/")+f"/api/v1/events/{event_type}"
    try:
        req=urllib.request.Request(url,data=json.dumps(payload).encode("utf-8"),headers={"Content-Type":"application/json","Accept":"application/json","X-Device-Token":str(cfg["device_token"])},method="POST")
        with urllib.request.urlopen(req,timeout=15) as r:
            return 200 <= r.status < 300, f"HTTP {r.status}"
    except urllib.error.HTTPError as e:
        if e.code == 401:
            try:
                cfg["device_token"]=""; save_remote_config(cfg); register_remote_device(cfg)
                req=urllib.request.Request(url,data=json.dumps(payload).encode("utf-8"),headers={"Content-Type":"application/json","Accept":"application/json","X-Device-Token":str(cfg["device_token"])},method="POST")
                with urllib.request.urlopen(req,timeout=15) as r: return 200 <= r.status < 300, f"HTTP {r.status}"
            except Exception as e2: return False, str(e2)
        return False, f"HTTP {e.code}"
    except Exception as e:
        return False, str(e)


def load_webhook():
    try:
        if WEBHOOK_CONFIG.exists():
            cfg = json.loads(WEBHOOK_CONFIG.read_text(encoding="utf-8"))
            return str(cfg.get("webhook_url", "")).strip()
    except Exception:
        pass
    return ""

def save_webhook(url):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    WEBHOOK_CONFIG.write_text(
        json.dumps({"webhook_url": url}, indent=2),
        encoding="utf-8"
    )

def test_discord_webhook():
    """Send a simple visible test message to verify the configured webhook."""
    url = load_webhook()
    if not url:
        return False, "No webhook is configured."

    ident = current_identity()
    payload = {
        "username": "Dukes Cheat Detector",
        "allowed_mentions": {"parse": []},
        "embeds": [{
            "title": "🟢 Dukes Cheat Detector — Webhook Test",
            "description": "The Discord webhook is working correctly.",
            "color": 0x57F287,
            "fields": [
                {"name": "👤 User", "value": f"`{ident['windows_user']}`", "inline": True},
                {"name": "💻 Computer", "value": f"`{ident['computer']}`", "inline": True},
            ],
            "footer": {"text": "This is only a connection test. No scan was performed."},
            "timestamp": datetime.now().astimezone().isoformat()
        }]
    }

    try:
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 CheatDetectorPro/1.0"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=15) as response:
            if 200 <= response.status < 300:
                return True, "Discord webhook test succeeded."
            return False, f"Discord returned HTTP {response.status}."
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return False, f"Discord HTTP {e.code}: {body[:800]}"
    except Exception as e:
        return False, f"Connection error: {e}"

def send_discord_log(scan_results):
    """Send an opt-in, clean Discord embed to the configured webhook."""
    url = load_webhook()
    if not url:
        return False, "Discord webhook is not configured."

    ident = current_identity()
    strong = [x for x in scan_results if x["score"] >= 90]
    suspicious = [x for x in scan_results if 70 <= x["score"] < 90]
    lower = [x for x in scan_results if x["score"] < 70]

    if strong:
        color = 0xED4245
        status = "🚨 STRONG DETECTION"
    elif suspicious:
        color = 0xFEE75C
        status = "⚠️ SUSPICIOUS"
    else:
        color = 0x57F287
        status = "✅ NO STRONG DETECTIONS"

    families = {}
    for x in scan_results:
        families[x["family"]] = families.get(x["family"], 0) + 1

    family_text = (
        "\n".join(f"• **{k}** × {v}" for k, v in sorted(families.items()))
        if families else "None"
    )
    if len(family_text) > 1024:
        family_text = family_text[:1021] + "..."

    details = []
    for x in scan_results[:20]:
        icon = "🚨" if x["score"] >= 90 else ("⚠️" if x["score"] >= 70 else "🔎")
        details.append(
            f'{icon} **{x["family"]}** — `{x["score"]}/100`\n'
            f'`{x["path"]}`'
        )

    if len(scan_results) > 20:
        details.append(f"...and {len(scan_results) - 20} more detection(s).")

    # Discord field values are limited to 1024 chars.
    detail_chunks = []
    current = ""
    for item in details:
        candidate = item if not current else current + "\n\n" + item
        if len(candidate) > 1000:
            if current:
                detail_chunks.append(current)
            current = item
        else:
            current = candidate
    if current:
        detail_chunks.append(current)

    embeds = [{
        "title": f"{status} • Dukes Cheat Detector",
        "description": f"**Scan completed** — {len(scan_results)} detection(s)",
        "color": color,
        "fields": [
            {"name": "👤 User", "value": f"`{ident['windows_user']}`", "inline": True},
            {"name": "💻 Computer", "value": f"`{ident['computer']}`", "inline": True},
            {"name": "🚨 Strong", "value": str(len(strong)), "inline": True},
            {"name": "⚠️ Suspicious", "value": str(len(suspicious)), "inline": True},
            {"name": "🔎 Lower-confidence", "value": str(len(lower)), "inline": True},
            {"name": "🦠 Detected Families", "value": family_text, "inline": False},
        ],
        "footer": {"text": "Detection-only • No files were modified"},
        "timestamp": datetime.now().astimezone().isoformat()
    }]

    if detail_chunks:
        embeds[0]["fields"].append({
            "name": "📋 Detection Details",
            "value": detail_chunks[0],
            "inline": False
        })
        for i, chunk in enumerate(detail_chunks[1:], 2):
            embeds.append({
                "title": f"Detection Details • Part {i}",
                "description": chunk,
                "color": color
            })

    payload = {
        "username": "Dukes Cheat Detector",
        "allowed_mentions": {"parse": []},
        "embeds": embeds[:10]
    }

    try:
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 CheatDetectorPro/1.0"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=15) as response:
            if 200 <= response.status < 300:
                return True, "Discord log sent."
            return False, f"Discord returned HTTP {response.status}"
    except Exception as e:
        return False, f"Discord send failed: {e}"


def current_identity():
    return {
        "windows_user": os.environ.get("USERNAME", getpass.getuser()),
        "computer": os.environ.get("COMPUTERNAME", "Unknown-PC"),
    }

def hash_password(password, salt):
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), 200_000
    ).hex()

def owner_configured():
    return CONFIG_FILE.exists()

def setup_owner_password(parent):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    p1 = simpledialog.askstring("Owner Setup", "Create your Owner password:", show="*", parent=parent)
    if not p1:
        return False
    p2 = simpledialog.askstring("Owner Setup", "Confirm your Owner password:", show="*", parent=parent)
    if p1 != p2:
        messagebox.showerror(APP_NAME, "Passwords do not match.", parent=parent)
        return False
    salt = secrets.token_hex(16)
    CONFIG_FILE.write_text(
        json.dumps({"salt": salt, "hash": hash_password(p1, salt)}),
        encoding="utf-8"
    )
    return True

def verify_owner(parent):
    if not owner_configured():
        return setup_owner_password(parent)
    try:
        cfg = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        p = simpledialog.askstring("Owner Login", "Owner password:", show="*", parent=parent)
        if p is None:
            return False
        return secrets.compare_digest(hash_password(p, cfg["salt"]), cfg["hash"])
    except Exception:
        return False

def write_audit_event(scan_results):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    ident = current_identity()
    detections = [{
        "family": x["family"],
        "score": x["score"],
        "reason": x["reason"],
        "path": x["path"],
        "source": x["source"]
    } for x in scan_results]
    event = {
        "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
        "user": ident["windows_user"],
        "computer": ident["computer"],
        "detections": detections,
    }
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")

def read_audit_events():
    if not LOG_FILE.exists():
        return []
    events = []
    try:
        for line in LOG_FILE.read_text(encoding="utf-8").splitlines():
            if line.strip():
                events.append(json.loads(line))
    except Exception:
        pass
    return list(reversed(events))

def is_likely_false_positive(path_or_text):
    t = norm(path_or_text)
    return any(hint in t for hint in FALSE_POSITIVE_HINTS)

def classify(text):
    """Heuristic name matching. Returns list of (family, score, reason).
    Scores are intentionally conservative to reduce false positives."""
    t = norm(text)
    out = []
    if is_likely_false_positive(t):
        return out

    for family, terms in KNOWN.items():
        for term in terms:
            if term in t:
                # Higher score only when term is distinctive / appears as filename stem
                base = 88
                if term.endswith(".exe") or term.endswith("_") or len(term) >= 7:
                    base = 94
                # Electron is extremely common in legit apps → heavy penalty
                if family == "Electron":
                    base = 55
                out.append((family, base, "Known family name match: " + term))
                break

    hits = [x for x in GENERIC if x in t]
    if hits and not out:
        # Generic terms alone are lower confidence
        score = min(72, 48 + 6 * len(hits))
        out.append((
            "Generic suspicious",
            score,
            "Suspicious term(s): " + ", ".join(hits[:4]),
        ))
    return out
def add(results,path,family,score,reason,source="filesystem"):
    try:
        p=Path(path); key=norm(p.resolve(strict=False))
    except Exception:
        p=Path(path); key=norm(path)
    if key in results:
        if score > results[key]["score"]:
            results[key].update(score=score,family=family,reason=reason,source=source)
        return
    try: kind="Folder" if p.is_dir() else "File"
    except OSError: kind="Unknown"
    results[key]={"path":str(p),"family":family,"score":score,"reason":reason,
                  "source":source,"kind":kind}

def scan_files(results):
    home = Path(os.environ.get("USERPROFILE", str(Path.home())))
    roots = [
        home / "Downloads", home / "Desktop", home / "Documents",
        home / "AppData" / "Local", home / "AppData" / "LocalLow",
        home / "AppData" / "Roaming",
        Path(os.environ.get("TEMP", tempfile.gettempdir())),
        Path(os.environ.get("ProgramData", r"C:\ProgramData")),
    ]
    skip = {
        "node_modules", ".git", "__pycache__", "cache", "code cache",
        "gpucache", "crashdumps", "package cache", "temp", "tmp",
    }
    for root in roots:
        if not root.exists():
            continue
        for d, dirs, files in os.walk(root, topdown=True):
            low = norm(d)
            if any(x in low for x in EXCLUDES):
                dirs[:] = []
                continue
            dirs[:] = [x for x in dirs if x.lower() not in skip]
            for name in files:
                p = Path(d) / name
                # Skip obvious legitimate system / browser paths early
                if is_likely_false_positive(str(p)):
                    continue
                hits = classify(str(p))
                if hits:
                    for fam, score, reason in hits:
                        boost = 4 if p.suffix.lower() in EXTS else 0
                        add(results, p, fam, min(100, score + boost), reason)
                elif p.suffix.lower() in EXTS:
                    name_hits = [x for x in GENERIC if x in norm(name)]
                    if name_hits:
                        add(
                            results, p, "Generic suspicious",
                            min(70, 50 + 8 * len(name_hits)),
                            "Suspicious executable name: " + ", ".join(name_hits[:3]),
                        )
def scan_processes(results):
    cmd=("Get-CimInstance Win32_Process | Select-Object ProcessId,Name,"
         "ExecutablePath,CommandLine | ConvertTo-Json -Compress")
    try:
        r=subprocess.run(["powershell","-NoProfile","-Command",cmd],
                         capture_output=True,text=True,timeout=25)
        data=json.loads(r.stdout) if r.stdout.strip() else []
        if isinstance(data,dict): data=[data]
        for p in data:
            blob=" ".join(str(p.get(k,"")) for k in ("Name","ExecutablePath","CommandLine"))
            for fam,score,reason in classify(blob):
                add(results,p.get("ExecutablePath") or p.get("Name") or "Unknown process",
                    fam,min(100,score+3),"Running process: "+reason,"running process")
        return
    except Exception: pass
    try:
        r=subprocess.run(["tasklist","/fo","csv","/nh"],capture_output=True,text=True,timeout=15)
        for line in r.stdout.splitlines():
            for fam,score,reason in classify(line):
                add(results,line,fam,score,"Running process: "+reason,"running process")
    except Exception: pass

def scan_startup(results):
    # Run/RunOnce keys: read-only query.
    cmd=("Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run',"
         "'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce',"
         "'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run',"
         "'HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce' "
         "-ErrorAction SilentlyContinue | ConvertTo-Json -Compress")
    try:
        r=subprocess.run(["powershell","-NoProfile","-Command",cmd],
                         capture_output=True,text=True,timeout=20)
        for fam,score,reason in classify(r.stdout):
            add(results,"Windows Registry startup entry",fam,score,
                "Startup persistence entry: "+reason,"startup")
    except Exception: pass
    home=Path(os.environ.get("USERPROFILE",str(Path.home())))
    dirs=[home/r"AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup",
          Path(os.environ.get("ProgramData",r"C:\ProgramData"))/
          r"Microsoft\Windows\Start Menu\Programs\StartUp"]
    for d in dirs:
        try:
            for p in d.iterdir():
                for fam,score,reason in classify(p):
                    add(results,p,fam,score,"Startup folder: "+reason,"startup")
        except OSError: pass

def scan_tasks(results):
    try:
        r=subprocess.run(["schtasks","/query","/fo","LIST","/v"],
                         capture_output=True,text=True,timeout=30)
        for fam,score,reason in classify(r.stdout):
            add(results,"Scheduled Task",fam,score,
                "Scheduled task contains: "+reason,"scheduled task")
    except Exception: pass

def scan_services(results):
    cmd=("Get-CimInstance Win32_Service | Select-Object Name,DisplayName,PathName "
         "| ConvertTo-Json -Compress")
    try:
        r=subprocess.run(["powershell","-NoProfile","-Command",cmd],
                         capture_output=True,text=True,timeout=25)
        data=json.loads(r.stdout) if r.stdout.strip() else []
        if isinstance(data,dict): data=[data]
        for s in data:
            blob=" ".join(str(s.get(k,"")) for k in ("Name","DisplayName","PathName"))
            for fam,score,reason in classify(blob):
                add(results,s.get("PathName") or s.get("Name") or "Windows Service",
                    fam,score,"Service entry: "+reason,"service")
    except Exception: pass

def do_scan():
    results={}
    scan_files(results); scan_processes(results); scan_startup(results)
    scan_tasks(results); scan_services(results)
    return sorted(results.values(),key=lambda x:(-x["score"],x["family"].lower(),x["path"].lower()))

class App(tk.Tk):
    BG = "#090909"
    PANEL = "#111111"
    PANEL2 = "#171717"
    RED = "#ff1f1f"
    RED2 = "#b80000"
    TEXT = "#f5f5f5"
    MUTED = "#a8a8a8"
    GREEN = "#39e66b"
    YELLOW = "#ffd33d"

    def __init__(self):
        super().__init__()
        self.title(APP_NAME + " v" + VERSION)
        self.geometry("1360x820")
        self.minsize(1050, 680)
        self.configure(bg=self.BG)
        self.results = []
        self.filtered_results = []
        self.scanning = False
        self.search_var = tk.StringVar()
        self.is_owner = False
        self._configure_styles()
        self._build_ui()
        # Ask for explicit permission on first run. No automatic scanning or reporting.
        self.after(200, self._ensure_consent)
        # Never auto-send launch events without consent (already gated inside send_remote_event)

    def _ensure_consent(self):
        """Show a clear permission dialog the first time the app is run."""
        cfg = load_remote_config()
        if cfg.get("local_scan_consent"):
            return  # already agreed

        msg = (
            "PERMISSION REQUIRED\n\n"
            "This tool scans your computer for known Roblox executor / cheat tool names.\n\n"
            "What it does:\n"
            "• Looks at file names in common folders (Downloads, Desktop, AppData, Temp…)\n"
            "• Checks running processes, startup entries, scheduled tasks and services\n"
            "• Uses name-matching heuristics only — it never modifies, deletes or uploads files\n\n"
            "What it does NOT do:\n"
            "• It is not proof of cheating (false positives are possible)\n"
            "• It does not send any data unless you later opt-in to remote reporting\n\n"
            "Do you give permission to perform local scans on this computer?"
        )
        ok = messagebox.askyesno(
            APP_NAME + " — Permission",
            msg,
            parent=self,
            icon="question",
        )
        cfg["local_scan_consent"] = bool(ok)
        # Remote reporting stays off until the user explicitly enables it in Settings
        cfg["consent"] = False
        save_remote_config(cfg)
        if not ok:
            messagebox.showinfo(
                APP_NAME,
                "Local scanning permission was denied.\n"
                "You can still open the app, but scanning is disabled until you grant permission in Settings.",
                parent=self,
            )
    def _configure_styles(self):
        st=ttk.Style(self)
        try: st.theme_use("clam")
        except tk.TclError: pass
        st.configure("TFrame", background=self.BG)
        st.configure("Panel.TFrame", background=self.PANEL)
        st.configure("Panel2.TFrame", background=self.PANEL2)
        st.configure("TLabel", background=self.BG, foreground=self.TEXT, font=("Segoe UI", 10))
        st.configure("Muted.TLabel", background=self.BG, foreground=self.MUTED, font=("Segoe UI", 9))
        st.configure("Title.TLabel", background=self.BG, foreground=self.TEXT, font=("Segoe UI", 25, "bold"))
        st.configure("Brand.TLabel", background=self.BG, foreground=self.RED, font=("Segoe UI", 12, "bold"))
        st.configure("Card.TFrame", background=self.PANEL, relief="solid", borderwidth=1)
        st.configure("CardTitle.TLabel", background=self.PANEL, foreground=self.MUTED, font=("Segoe UI", 9, "bold"))
        st.configure("CardValue.TLabel", background=self.PANEL, foreground=self.TEXT, font=("Segoe UI", 22, "bold"))
        st.configure("Red.CardValue.TLabel", background=self.PANEL, foreground=self.RED, font=("Segoe UI", 22, "bold"))
        st.configure("Green.CardValue.TLabel", background=self.PANEL, foreground=self.GREEN, font=("Segoe UI", 22, "bold"))
        st.configure("Yellow.CardValue.TLabel", background=self.PANEL, foreground=self.YELLOW, font=("Segoe UI", 22, "bold"))
        st.configure("TButton", background=self.PANEL2, foreground=self.TEXT, borderwidth=1, padding=(12,8), font=("Segoe UI",9,"bold"))
        st.map("TButton", background=[("active", self.RED2)], foreground=[("active", "white")])
        st.configure("Accent.TButton", background=self.RED, foreground="white", padding=(18,11), font=("Segoe UI",10,"bold"))
        st.map("Accent.TButton", background=[("active", "#ff4b4b"), ("disabled", "#5a1717")])
        st.configure("Nav.TButton", background=self.PANEL, foreground=self.TEXT, anchor="w", padding=(14,10), borderwidth=0)
        st.map("Nav.TButton", background=[("active", self.RED2)], foreground=[("active", "white")])
        st.configure("Search.TEntry", fieldbackground="#151515", foreground=self.TEXT, insertcolor=self.RED, padding=9)
        st.configure("Treeview", background="#0d0d0d", fieldbackground="#0d0d0d", foreground=self.TEXT, rowheight=30, borderwidth=0, font=("Segoe UI",9))
        st.configure("Treeview.Heading", background="#1b1b1b", foreground=self.TEXT, font=("Segoe UI",9,"bold"), padding=8)
        st.map("Treeview", background=[("selected", "#5f1010")], foreground=[("selected", "white")])

    def _build_ui(self):
        # Sidebar
        sidebar=tk.Frame(self,bg="#0c0c0c",width=220)
        sidebar.pack(side="left",fill="y"); sidebar.pack_propagate(False)
        brand=tk.Frame(sidebar,bg="#0c0c0c"); brand.pack(fill="x",padx=18,pady=(24,28))
        tk.Label(brand,text="♛",bg="#0c0c0c",fg=self.RED,font=("Segoe UI",27,"bold")).pack(side="left")
        tk.Label(brand,text="DUKES\nCHEAT DETECTOR",bg="#0c0c0c",fg="white",justify="left",font=("Segoe UI",11,"bold")).pack(side="left",padx=8)
        tk.Label(sidebar,text="PROTECTION CENTER",bg="#0c0c0c",fg="#777",font=("Segoe UI",8,"bold")).pack(anchor="w",padx=18,pady=(0,8))
        for text,cmd in [("⌂   Dashboard",self._dashboard),("⌕   Scan",self.start),("▤   Logs",self.show_audit_log),("⚙   Settings",self.remote_settings),("ⓘ   About",self._about)]:
            b=ttk.Button(sidebar,text=text,style="Nav.TButton",command=cmd); b.pack(fill="x",padx=10,pady=2)
        tk.Frame(sidebar,bg="#262626",height=1).pack(fill="x",padx=18,pady=20)
        self.owner_btn=ttk.Button(sidebar,text="♙  Owner Login",command=self.owner_login,style="Nav.TButton"); self.owner_btn.pack(fill="x",padx=10,pady=2)
        self.webhook_btn=ttk.Button(sidebar,text="◈  Discord Settings",command=self.discord_settings,style="Nav.TButton",state="disabled"); self.webhook_btn.pack(fill="x",padx=10,pady=2)
        bottom=tk.Frame(sidebar,bg="#0c0c0c"); bottom.pack(side="bottom",fill="x",padx=18,pady=18)
        tk.Label(bottom,text="●  REAL-TIME PROTECTION",bg="#0c0c0c",fg=self.GREEN,font=("Segoe UI",8,"bold")).pack(anchor="w")
        tk.Label(bottom,text="Detection-only • Nothing modified",bg="#0c0c0c",fg="#777",font=("Segoe UI",8)).pack(anchor="w",pady=(4,0))

        # Main
        main=tk.Frame(self,bg=self.BG); main.pack(side="left",fill="both",expand=True)
        header=tk.Frame(main,bg=self.BG); header.pack(fill="x",padx=30,pady=(24,14))
        left=tk.Frame(header,bg=self.BG); left.pack(side="left")
        tk.Label(left,text="Dukes Cheat Detector",bg=self.BG,fg="white",font=("Segoe UI",25,"bold")).pack(anchor="w")
        tk.Label(left,text="Protecting fair play. Detecting cheats.",bg=self.BG,fg=self.MUTED,font=("Segoe UI",10)).pack(anchor="w",pady=(3,0))
        statusbox=tk.Frame(header,bg="#160606",highlightbackground=self.RED,highlightthickness=1)
        statusbox.pack(side="right",ipadx=18,ipady=9)
        tk.Label(statusbox,text="●  STATUS",bg="#160606",fg=self.RED,font=("Segoe UI",9,"bold")).pack(anchor="w")
        self.header_status=tk.Label(statusbox,text="RUNNING",bg="#160606",fg="white",font=("Segoe UI",13,"bold")); self.header_status.pack(anchor="w")
        tk.Label(statusbox,text="v"+VERSION,bg="#160606",fg="#888",font=("Segoe UI",8)).pack(anchor="w")

        # Cards
        cards=tk.Frame(main,bg=self.BG); cards.pack(fill="x",padx=30,pady=(0,18))
        self.card_detections=self._card(cards,"DETECTIONS","0","Red.CardValue.TLabel")
        self.card_strong=self._card(cards,"STRONG MATCHES","0","Red.CardValue.TLabel")
        self.card_clean=self._card(cards,"STATUS","READY","Green.CardValue.TLabel")
        self.card_user=self._card(cards,"WINDOWS USER",current_identity()["windows_user"],"CardValue.TLabel")

        actions=tk.Frame(main,bg=self.BG); actions.pack(fill="x",padx=30,pady=(0,14))
        searchbox=tk.Frame(actions,bg=self.PANEL,highlightbackground="#2a2a2a",highlightthickness=1)
        searchbox.pack(side="left",fill="x",expand=True,ipady=2)
        tk.Label(searchbox,text="⌕",bg=self.PANEL,fg=self.RED,font=("Segoe UI",16,"bold")).pack(side="left",padx=(10,4))
        self.search_entry=ttk.Entry(searchbox,textvariable=self.search_var,style="Search.TEntry")
        self.search_entry.pack(side="left",fill="x",expand=True,padx=(0,6),pady=4)
        self.search_entry.bind("<KeyRelease>",lambda e:self.apply_search()); self.search_entry.bind("<Escape>",lambda e:self.clear_search())
        ttk.Button(actions,text="Clear",command=self.clear_search).pack(side="left",padx=8)
        self.btn=ttk.Button(actions,text="⚡  START FULL SCAN",command=self.start,style="Accent.TButton"); self.btn.pack(side="left")
        ttk.Button(actions,text="Export Report",command=self.export).pack(side="left",padx=(8,0))

        panel=tk.Frame(main,bg=self.PANEL,highlightbackground="#2a2a2a",highlightthickness=1); panel.pack(fill="both",expand=True,padx=30,pady=(0,18))
        title=tk.Frame(panel,bg=self.PANEL); title.pack(fill="x",padx=16,pady=(14,8))
        tk.Label(title,text="Detection Activity",bg=self.PANEL,fg="white",font=("Segoe UI",12,"bold")).pack(side="left")
        self.status=tk.Label(title,text="Ready.",bg=self.PANEL,fg=self.MUTED,font=("Segoe UI",9)); self.status.pack(side="right")
        frame=tk.Frame(panel,bg=self.PANEL); frame.pack(fill="both",expand=True,padx=12,pady=(0,12))
        cols=("score","family","kind","source","reason","path")
        self.tree=ttk.Treeview(frame,columns=cols,show="headings",selectmode="extended")
        heads={"score":"SCORE","family":"FAMILY","kind":"TYPE","source":"SOURCE","reason":"REASON","path":"PATH / LOCATION"}
        widths={"score":70,"family":145,"kind":85,"source":125,"reason":330,"path":600}
        for c in cols:
            self.tree.heading(c,text=heads[c]); self.tree.column(c,width=widths[c],stretch=(c=="path"))
        self.tree.tag_configure("danger",foreground="#ff6b6b"); self.tree.tag_configure("warning",foreground="#ffd33d")
        vs=ttk.Scrollbar(frame,orient="vertical",command=self.tree.yview); hs=ttk.Scrollbar(frame,orient="horizontal",command=self.tree.xview)
        self.tree.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        self.tree.grid(row=0,column=0,sticky="nsew"); vs.grid(row=0,column=1,sticky="ns"); hs.grid(row=1,column=0,sticky="ew")
        frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)
        self.owner_status=tk.Label(main,text="STANDARD USER",bg=self.BG,fg="#777",font=("Segoe UI",8,"bold")); self.owner_status.pack(anchor="w",padx=30,pady=(0,8))
        tk.Label(
            main,
            text="Detection scores are heuristics, not proof. False positives possible. Renamed, encrypted, memory-only and kernel-level cheats may evade. Always ask permission before scanning another person’s PC.",
            bg=self.BG, fg="#666", font=("Segoe UI", 8),
        ).pack(anchor="w", padx=30, pady=(0, 12))
        self.bind("<Control-f>", self.focus_search)

    def _card(self,parent,title,value,style):
        box=tk.Frame(parent,bg=self.PANEL,highlightbackground="#2a2a2a",highlightthickness=1)
        box.pack(side="left",fill="x",expand=True,padx=(0,10))
        ttk.Label(box,text=title,style="CardTitle.TLabel").pack(anchor="w",padx=15,pady=(12,0))
        lab=ttk.Label(box,text=value,style=style); lab.pack(anchor="w",padx=15,pady=(3,12))
        return lab

    def _dashboard(self):
        self.status.config(text="Dashboard ready.")

    def _about(self):
        messagebox.showinfo(
            APP_NAME,
            f"Dukes Cheat Detector\nVersion {VERSION}\n\n"
            "Detection-only scanner for known Roblox executor / cheat tool names.\n"
            "Nothing is modified, deleted or uploaded without your permission.\n\n"
            "Results are heuristics — not legal proof. False positives are possible.\n"
            "Always obtain consent before scanning someone else’s computer.",
            parent=self,
        )
    def clear(self):
        for x in self.tree.get_children(): self.tree.delete(x)
        self.results=[]; self.filtered_results=[]; self.search_var.set("")
        self.card_detections.config(text="0"); self.card_strong.config(text="0"); self.card_clean.config(text="READY")

    def focus_search(self,event=None):
        self.search_entry.focus_set(); self.search_entry.select_range(0,tk.END); return "break"

    def clear_search(self):
        self.search_var.set(""); self.apply_search(); self.search_entry.focus_set()

    def apply_search(self):
        query=self.search_var.get().strip().lower()
        if not query: self.filtered_results=list(self.results)
        else:
            self.filtered_results=[x for x in self.results if any(query in str(x[k]).lower() for k in ("family","path","reason","source","kind","score"))]
        for item in self.tree.get_children(): self.tree.delete(item)
        for x in self.filtered_results:
            tag="danger" if x["score"]>=90 else ("warning" if x["score"]>=70 else "")
            self.tree.insert("","end",values=(x["score"],x["family"],x["kind"],x["source"],x["reason"],x["path"]),tags=(tag,))
        if query: self.status.config(text=f'{len(self.filtered_results)} result(s) matching "{self.search_var.get()}"')
        elif not self.scanning: self._update_summary()

    def _update_summary(self):
        strong=sum(x["score"]>=90 for x in self.results)
        self.card_detections.config(text=str(len(self.results)))
        self.card_strong.config(text=str(strong))
        self.card_clean.config(text="CLEAN" if not self.results else "REVIEW")
        self.status.config(text=f"Scan complete • {len(self.results)} detection(s) • {strong} strong match(es)")

    def owner_login(self):
        if self.is_owner:
            self.is_owner=False; self.owner_btn.config(text="♙  Owner Login"); self.webhook_btn.config(state="disabled"); self.owner_status.config(text="STANDARD USER",fg="#777"); return
        if verify_owner(self):
            self.is_owner=True; self.webhook_btn.config(state="normal"); self.owner_btn.config(text="♙  Lock Owner"); self.owner_status.config(text="OWNER MODE — AUDIT ACCESS ENABLED",fg=self.GREEN)
        else: messagebox.showerror(APP_NAME,"Owner authentication failed.",parent=self)

    def discord_settings(self):
        if not self.is_owner:
            if not verify_owner(self): messagebox.showerror(APP_NAME,"Owner permissions are required.",parent=self); return
            self.is_owner=True; self.webhook_btn.config(state="normal"); self.owner_btn.config(text="♙  Lock Owner"); self.owner_status.config(text="OWNER MODE — AUDIT ACCESS ENABLED",fg=self.GREEN)
        win=tk.Toplevel(self); win.title("Discord Log Settings"); win.geometry("700x280"); win.resizable(False,False)
        ttk.Label(win,text="Discord Webhook",font=("Segoe UI",18,"bold"),padding=12).pack(anchor="w")
        ttk.Label(win,text="Optional owner-only reporting. Keep the webhook secret.",wraplength=650,padding=(12,0,12,10)).pack(anchor="w")
        row=ttk.Frame(win,padding=12); row.pack(fill="x"); ttk.Label(row,text="Webhook URL:").pack(side="left")
        var=tk.StringVar(value=load_webhook()); entry=ttk.Entry(row,textvariable=var,width=70,show="*"); entry.pack(side="left",padx=(8,0),fill="x",expand=True)
        send_var=tk.BooleanVar(value=bool(load_webhook())); ttk.Checkbutton(win,text="Send a Discord message after each completed scan",variable=send_var).pack(anchor="w",padx=12,pady=4)
        def save():
            url=var.get().strip()
            if send_var.get() and not url: messagebox.showerror(APP_NAME,"Enter a webhook URL or disable Discord logging.",parent=win); return
            save_webhook(url if send_var.get() else ""); messagebox.showinfo(APP_NAME,"Discord settings saved.",parent=win); win.destroy()
        def test():
            url=var.get().strip()
            if not url: messagebox.showerror(APP_NAME,"Paste a Discord webhook URL first.",parent=win); return
            save_webhook(url); ok,msg=test_discord_webhook(); (messagebox.showinfo if ok else messagebox.showerror)(APP_NAME,msg,parent=win)
        ttk.Button(win,text="Test Webhook",command=test).pack(side="left",padx=12,pady=12); ttk.Button(win,text="Save",command=save).pack(side="right",padx=12,pady=12); ttk.Button(win,text="Cancel",command=win.destroy).pack(side="right",pady=12)

    def remote_settings(self):
        cfg = load_remote_config()
        win = tk.Toplevel(self)
        win.title("Permissions & Remote Reporting")
        win.geometry("720x380")
        win.resizable(False, False)

        ttk.Label(win, text="Permissions & Remote Reporting", font=("Segoe UI", 18, "bold"), padding=12).pack(anchor="w")
        ttk.Label(
            win,
            text=(
                "Local scans look for known cheat/executor names on this PC only.\n"
                "Remote reporting (optional) sends launch/scan metadata to the configured owner dashboard.\n"
                "Nothing is sent without your explicit agreement. You can change these settings at any time."
            ),
            wraplength=680,
            padding=(12, 0, 12, 12),
        ).pack(anchor="w")

        local_var = tk.BooleanVar(value=bool(cfg.get("local_scan_consent", False)))
        ttk.Checkbutton(
            win,
            text="I grant permission for local scans on this computer",
            variable=local_var,
        ).pack(anchor="w", padx=12, pady=6)

        consent = tk.BooleanVar(value=bool(cfg.get("consent", False)))
        ttk.Checkbutton(
            win,
            text="I agree to send launch and scan metadata to the owner dashboard (optional)",
            variable=consent,
        ).pack(anchor="w", padx=12, pady=6)

        status = tk.StringVar(value="")
        ttk.Label(win, textvariable=status, padding=12, wraplength=680).pack(anchor="w")

        def save():
            cfg["local_scan_consent"] = local_var.get()
            cfg["consent"] = consent.get()
            save_remote_config(cfg)
            status.set(
                "Saved. Local scanning: "
                + ("enabled" if cfg["local_scan_consent"] else "disabled")
                + ". Remote reporting: "
                + ("enabled" if cfg["consent"] else "disabled")
                + "."
            )
            if cfg["consent"]:
                threading.Thread(target=send_remote_event, args=("launch", []), daemon=True).start()

        ttk.Button(win, text="Save", command=save).pack(side="right", padx=12, pady=12)
        ttk.Button(win, text="Cancel", command=win.destroy).pack(side="right", pady=12)
    def show_audit_log(self):
        if not self.is_owner: messagebox.showerror(APP_NAME,"Owner permissions are required.",parent=self); return
        win=tk.Toplevel(self); win.title("Owner Audit Log"); win.geometry("1100x650")
        ttk.Label(win,text="Owner Audit Log",font=("Segoe UI",18,"bold"),padding=12).pack(anchor="w")
        ttk.Label(win,text="Local scan history for this PC. Remote events are shown on the owner dashboard.",wraplength=1000,padding=(12,0,12,10)).pack(anchor="w")
        frame=ttk.Frame(win,padding=12); frame.pack(fill="both",expand=True)
        cols=("time","user","computer","count","families"); tree=ttk.Treeview(frame,columns=cols,show="headings")
        heads={"time":"Time","user":"Windows User","computer":"Computer","count":"Detections","families":"Detected Families"}; widths={"time":180,"user":140,"computer":160,"count":90,"families":450}
        for c in cols: tree.heading(c,text=heads[c]); tree.column(c,width=widths[c],stretch=(c=="families"))
        vs=ttk.Scrollbar(frame,orient="vertical",command=tree.yview); tree.configure(yscrollcommand=vs.set); tree.grid(row=0,column=0,sticky="nsew"); vs.grid(row=0,column=1,sticky="ns"); frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)
        events=read_audit_events()
        for e in events:
            families=sorted(set(d.get("family","Unknown") for d in e.get("detections",[]))); tree.insert("","end",values=(e.get("timestamp",""),e.get("user",""),e.get("computer",""),len(e.get("detections",[])),", ".join(families)))
        def details(event=None):
            sel=tree.selection();
            if not sel:return
            idx=tree.index(sel[0]); e=events[idx]; detail=tk.Toplevel(win); detail.title("Scan Details"); detail.geometry("1000x600"); txt=tk.Text(detail,wrap="none",bg="#0d0d0d",fg="white",insertbackground="white"); txt.pack(fill="both",expand=True,padx=12,pady=12)
            lines=[f'Time: {e.get("timestamp","")}',f'Windows User: {e.get("user","")}',f'Computer: {e.get("computer","")}',"","DETECTIONS:"]
            for i,d in enumerate(e.get("detections",[]),1): lines.append(f'{i}. [{d.get("score","?")}] {d.get("family","Unknown")} | {d.get("source","")} | {d.get("reason","")} | {d.get("path","")}')
            txt.insert("1.0","\n".join(lines)); txt.config(state="disabled")
        tree.bind("<Double-1>",details)
        def export_log():
            p=filedialog.asksaveasfilename(parent=win,title="Export Owner Audit Log",defaultextension=".jsonl",filetypes=[("JSON Lines","*.jsonl"),("Text","*.txt")])
            if not p:return
            Path(p).write_text("\n".join(json.dumps(e,ensure_ascii=False) for e in events),encoding="utf-8"); messagebox.showinfo(APP_NAME,"Audit log exported.",parent=win)
        ttk.Button(win,text="Export Log",command=export_log).pack(side="right",padx=12,pady=(0,12))

    def start(self):
        if self.scanning:
            return
        cfg = load_remote_config()
        if not cfg.get("local_scan_consent"):
            messagebox.showwarning(
                APP_NAME,
                "Local scanning permission has not been granted.\n\n"
                "Open Settings and enable “I grant permission for local scans on this computer” first.",
                parent=self,
            )
            return
        self.scanning = True
        self.btn.config(state="disabled")
        self.header_status.config(text="SCANNING", fg=self.YELLOW)
        self.card_clean.config(text="SCANNING")
        self.status.config(text="Deep scan running… this may take several minutes.")
        threading.Thread(target=self.worker, daemon=True).start()
    def worker(self):
        try: r=do_scan(); self.after(0,lambda:self.done(r))
        except Exception as e: self.after(0,lambda:self.error(str(e)))

    def error(self,e):
        self.scanning=False; self.btn.config(state="normal"); self.header_status.config(text="ERROR",fg=self.RED); self.card_clean.config(text="ERROR"); self.status.config(text="Scan failed."); messagebox.showerror(APP_NAME,e,parent=self)

    def done(self,r):
        self.results=r
        try: write_audit_event(r)
        except Exception: pass
        detections=[{"family":x["family"],"score":x["score"],"reason":x["reason"],"path":x["path"],"source":x["source"],"kind":x["kind"]} for x in r]
        cfg = load_remote_config()
        if cfg.get("consent"):  # only if user explicitly opted in
            threading.Thread(target=send_remote_event, args=("scan", detections), daemon=True).start()
        if load_webhook():
            threading.Thread(target=send_discord_log,args=(r,),daemon=True).start()
        self.filtered_results=list(r); self.apply_search(); self.scanning=False; self.btn.config(state="normal"); self.header_status.config(text="RUNNING",fg=self.RED); self._update_summary()

    def export(self):
        if not self.results: messagebox.showinfo(APP_NAME,"There are no detections to export.",parent=self); return
        p=filedialog.asksaveasfilename(title="Save detection report",defaultextension=".txt",filetypes=[("Text files","*.txt"),("All files","*.*")])
        if not p:return
        lines=[APP_NAME+" v"+VERSION,"Scan time: "+datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"DETECTION-ONLY REPORT — nothing was modified.",""]
        for i,x in enumerate(self.results,1): lines.append(f'{i}. Score={x["score"]} | Family={x["family"]} | Type={x["kind"]} | Source={x["source"]} | Reason={x["reason"]} | Path={x["path"]}')
        Path(p).write_text("\n".join(lines),encoding="utf-8"); messagebox.showinfo(APP_NAME,"Report saved to:\n"+p,parent=self)

if __name__=="__main__":
    App().mainloop()
