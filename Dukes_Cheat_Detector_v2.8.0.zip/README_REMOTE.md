DUKES CHEAT DETECTOR REMOTE REPORTING

Client: dukes_cheat_detector.py
Server: owner_server.py

Version 2.8.0+ requires explicit user permission:
- Local scanning only works after the user grants permission (first-run dialog + Settings).
- Remote reporting is OFF by default and only activates if the user opts in via Settings.

The client is preconfigured for https://cheat-detector-server.onrender.com and registers a device token only when consent is given. No server URL or ingest token is entered by end users.

RENDER: set DISCORD_WEBHOOK_URL as an Environment Variable on the web service. Do not put the webhook in the client. Also set OWNER_PASSWORD and FLASK_SECRET.

Deploy owner_server.py to the Render service.
